from rest_framework import serializers

from students.models import Student, StudentFather, StudentMother, StudentContract


class StudentFatherSerializer(serializers.ModelSerializer):
    class Meta:
        model = StudentFather
        fields = '__all__'


class StudentMotherSerializer(serializers.ModelSerializer):
    class Meta:
        model = StudentMother
        fields = '__all__'


class ContractSerializer(serializers.ModelSerializer):
    class Meta:
        model = StudentContract
        fields = '__all__'
class StudentSerializer(serializers.ModelSerializer):
    father = StudentFatherSerializer()
    mother = StudentMotherSerializer()
    contract = ContractSerializer()
    class Meta:
        model = Student
        fields = ('name','surname','jshr','student_img','age','ball','father','mother','contract')

    def create(self, validated_data):
        # Extract nested data for Father, Mother, and Contract
        father_data = validated_data.pop('father')
        mother_data = validated_data.pop('mother')
        contract_data = validated_data.pop('contract')

        # Create Father, Mother, and Contract instances
        father_instance = StudentFather.objects.create(**father_data)
        mother_instance = StudentMother.objects.create(**mother_data)
        contract_instance = StudentContract.objects.create(**contract_data)

        # Create Student instance with references to Father, Mother, and Contract
        student_instance = Student.objects.create(
            father=father_instance,
            mother=mother_instance,
            contract=contract_instance,
            **validated_data
        )

        return student_instance


    def update(self, instance, validated_data):

        instance.name = validated_data.get('name', instance.name)
        instance.surname = validated_data.get('surname', instance.surname)
        instance.age = validated_data.get('age', instance.age)
        # ... add other fields as needed

        father_data = validated_data.pop('father', {})
        mother_data = validated_data.pop('mother', {})
        contract_data = validated_data.pop('contract', {})

        father_instance = instance.father
        mother_instance = instance.mother
        contract_instance = instance.contract

        StudentFatherSerializer().update(father_instance, father_data)
        StudentMotherSerializer().update(mother_instance, mother_data)
        ContractSerializer().update(contract_instance, contract_data)

        instance.save()
        return instance

