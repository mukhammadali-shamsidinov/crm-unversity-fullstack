from django.db import models

# Create your models here.
class Student(models.Model):
    name,surname = models.CharField(max_length=155),models.CharField(max_length=155)
    age = models.IntegerField()
    jshr = models.CharField(max_length=14)
    FACULTY = (
        ('Copyuter Since','Copyuter Since'),
        ('Pisixologiya','Pisixologiya')
    )
    student_img = models.ImageField(upload_to='students/',blank=True,null=True)
    faculty = models.CharField(choices=FACULTY,blank=False,max_length=255)
    father = models.ForeignKey('StudentFather',on_delete=models.CASCADE)
    mother = models.ForeignKey('StudentMother',on_delete=models.CASCADE)
    contract = models.ForeignKey('StudentContract',on_delete=models.CASCADE)
    ball = models.IntegerField(default=0)

    def __str__(self):
        return f"{self.name} {self.surname}"


class StudentFather(models.Model):
    name,surname = models.CharField(max_length=155),models.CharField(max_length=155)
    age = models.IntegerField()
    jshr = models.CharField(max_length=14)

class StudentMother(models.Model):
    name,surname = models.CharField(max_length=155),models.CharField(max_length=155)
    age = models.IntegerField()
    jshr = models.CharField(max_length=14)

class StudentContract(models.Model):
    PRICE = (
        ('grand','grand'),
        ('1000','1000'),
        ('2000','2000')
    )
    price = models.CharField(max_length=155,choices=PRICE)