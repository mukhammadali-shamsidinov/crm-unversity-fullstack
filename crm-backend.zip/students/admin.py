from django.contrib import admin

from students.models import Student,StudentContract,StudentFather,StudentMother

# Register your models here.
admin.site.register(Student)
admin.site.register(StudentMother)
admin.site.register(StudentFather)
admin.site.register(StudentContract)
