from django.shortcuts import render
from rest_framework import status
from rest_framework.authentication import TokenAuthentication
from rest_framework.authtoken.models import Token
from rest_framework.authtoken.views import ObtainAuthToken
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from users.serializers import UserSerializer


# Create your views here.
class RegisterView(APIView):
    def post(self, request):
        serializer = UserSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            token, created = Token.objects.get_or_create(user=user)

            return Response(
                data={
                    'message': 'successfully registered',
                    'token':token.key
                }
            )

class LoginView(ObtainAuthToken):
    def post(self, request):
        serializer = super(LoginView, self).post(request)
        token = serializer.data.get('token')

        if token:
            return Response(
                data={
                    'message': 'success',
                    'token':token
                }
            )
        else:
            return Response({
                'message': 'Login failed',
                'error': 'Invalid credentials'
            }, status=status.HTTP_401_UNAUTHORIZED)

class LogoutApiView(APIView):
    authentication_classes = [TokenAuthentication]
    permission_classes = [IsAuthenticated]
    def post(self, request):
        request.auth.delete()
        return Response(
            data={
                'message': 'logout successful'
            }
        )