from django.db.migrations import serializer
from django.shortcuts import render
from django.views.generic import ListView
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from rest_framework.response import Response
from rest_framework.views import APIView

from students.models import Student
from students.serializers import StudentSerializer


# Create your views here.
class StudentListApiView(APIView):
    permission_classes = [IsAuthenticated]
    def get(self, request):
        students = Student.objects.all()
        serializer = StudentSerializer(students, many=True).data

        return Response(
            data=serializer
        )


class StudentDetailApiView(APIView):
    permission_classes = [IsAuthenticated]
    def get(self, request, pk):
        student = Student.objects.get(id=pk)
        serializer = StudentSerializer(student).data

        return Response(
            data=serializer
        )


class StudentCreateApiView(APIView):

    def post(self,request):
        serializer = StudentSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(
                data={
                    'message': 'Student created successfully'
                }
            )



class StudentUpdateApiView(APIView):
    permission_classes = [IsAdminUser]

    def post(self,request,pk):
        student = Student.objects.get(id=pk)

        serializer = StudentSerializer(student,data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response(
                data=serializer.data
            )


class StudentDeleteApiView(APIView):
    permission_classes = [IsAdminUser]

    def delete(self,request,pk):
        student = Student.objects.get(id=pk)

        student.delete()
        return Response(
            data={'message': 'Student deleted successfully'}
        )