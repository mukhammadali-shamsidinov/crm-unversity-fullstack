from django.urls import path

from students.views import StudentListApiView,StudentDetailApiView,StudentCreateApiView,StudentUpdateApiView,StudentDeleteApiView

urlpatterns = [
    path('all/',StudentListApiView.as_view()),
    path('<int:pk>/', StudentDetailApiView.as_view()),
    path('create/',StudentCreateApiView.as_view()),
    path('update/<int:pk>/', StudentUpdateApiView.as_view()),
    path('delete/<int:pk>', StudentDeleteApiView.as_view())
]